Konghwan Shin
KS54897
Jul 1 2022

Flood Fill
-This program have a rectangular character in a .txt file. This is a picture. This allows the user to flood fill the program with the desired inputs they want. The connecting pixel has the same color characters and the user can change pixel by typing their desired input for the row and column and color. To end the program enter -1 for either row or column. 

 The program uses a Stack Abstract Data Type (ADT) implemented using a linked list structure.
 
How to run:
-unzip the content of the zip file into the Linux directory and then type in the make command. After that a makefile will compile
-To install the program, unzip the contents into a Linux directory and execute the "make" command. The makefile provided will compile and link the program successfully. Make sure that your desired picture in .txt format is located in the same directory as the program files. To run the program, use the following command: ./flood_fill fake_picture.txt
Potential Issues:
-The user is required to provide integer values for the column and row inputs, and single characters representing the desired color.