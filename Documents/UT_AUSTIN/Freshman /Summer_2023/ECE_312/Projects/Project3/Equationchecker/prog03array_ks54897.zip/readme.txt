Konghwan Shin
KS54897
Jul 1 2022

Equation checker: 
-For this program, the program detects bracket flaws in writing code. For example, when there is a given code of (3-1)*2 this will output "valid". However, (3-1]*2 will output invalid. The program determines wether the parenthesis, square, braces and angle braces match. 

 The program uses a 
 
How to run:
-unzip the content of the zip file into the Linux directory and then type in the make command. After that a makefile will compile
-To install the program, unzip the contents into a Linux directory and execute the "make" command. The makefile provided will compile and link the program successfully. Make sure that your desired picture in .txt format is located in the same directory as the program files. To run the program, use the following command: ./equation check.txt
Potential Issues:
-The program checks parenthesis, square, braces, and angle braces for an equation and outputs whether it has matching or not matching. If the user inputs a different braces other than the 4(parenthesis, square, braces, and angle braces) it will not produce the user wanted output