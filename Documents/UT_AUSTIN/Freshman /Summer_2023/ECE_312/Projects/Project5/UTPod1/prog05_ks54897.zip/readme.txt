Konghwan Shin
KS54897
Jul 20 2022


UTPod
-The UTPod is a simplified version of the iPod, designed to store and manage a linked list of songs. This README file provides an overview of the UTPod implementation, including classes, methods, functionality, assumptions, known bugs, and instructions on how to build and run the program.
-The UTPod is responsible for managing the linked list of songs.
-The Song is outputs the artists, songs, and the size of the songs.
How to run:
-unzip the content of the zip file into the Linux directory and then type in the make command. After that, a makefile will compile
-To install the program, unzip the contents into a Linux directory and execute the "make" command. The makefile provided will compile and link the program successfully.To run the program, use the following command: ./utpod
Potential Issues:
-The user can add multiple the same songs which can cause the the UTpod to have redundant songs.