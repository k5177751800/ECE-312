Konghwan Shin
ECE 312
KS54897
Aug 10, 2023

Cheaters:
-Cheaters check plagiarism in essays. When checking for plagiarism, it removes all the punctuation and special characters and changes uppercases to lower cases. However, it doesn't remove apostrophes. Apostrophes remain when checking for plagiarism. The code creates a p-word sequence of the two essay. 
How to run:
-unzip the content of the zip file into the Linux directory and then type in the make command. After that, a makefile will compile
-To install the program, unzip the contents into a Linux directory and execute the "make" command. The makefile provided will compile and link the program successfully. Make sure that your desired essay file in .txt format is located in the same directory as the program files. To run the program, use the following command: ./plagiarismCatcher sm_doc_set 6 200. 
To test the following time of the code, type the command: time ./plagiarismCatcher sm_doc_set 6 200. 
Potential Issues:
None.


