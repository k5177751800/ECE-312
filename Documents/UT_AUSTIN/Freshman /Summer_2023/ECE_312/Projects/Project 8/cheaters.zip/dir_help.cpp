#include <sys/types.h>
#include <dirent.h>
#include <errno.h>
#include <vector>
#include <string>
#include <iostream>

using namespace std;

int getdir (string dir, vector<string> &files) {
  DIR *dp;
  struct dirent *dirp;
  if((dp  = opendir(dir.c_str())) == NULL) {
    cout << "Error(" << errno << ") opening " << dir << endl;
    return errno;
  }
  
  while ((dirp = readdir(dp)) != NULL) {
    files.push_back(string(dirp->d_name));
  }
  closedir(dp);
  return 0;
}

int main(int argc, char *argv[]) {
  
  if (argc < 2) {
    cout << "ERROR: enter directory name as an argument" << endl;
    return (0);
  }
  string dir = argv[1];
  vector<string> files = vector<string>();
  string str;

  getdir(dir,files);
  
  for (unsigned int i = 2; i < files.size(); i++) {
    // ignore . and ..
    cout << files[i] << endl;
  }
			  
  return 0;
}
