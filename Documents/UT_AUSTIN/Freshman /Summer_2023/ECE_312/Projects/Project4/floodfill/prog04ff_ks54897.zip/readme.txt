Konghwan Shin
KS54897
Jul 11 2022


Flood Fill
-the Flood Fill problem involves manipulating a grid of characters representing colors in a picture. The program reads an input file that contains a grid of characters and repeatedly prompts the user for a row and column number, as well as a new color. The program then performs a flood fill operation, changing the color of the specified area and displaying the updated picture. The program continues to prompt the user until they enter -1 for the row or column.

 The program uses Recursion
 
How to run:
-unzip the content of the zip file into the Linux directory and then type in the make command. After that, a makefile will compile
-To install the program, unzip the contents into a Linux directory and execute the "make" command. The makefile provided will compile and link the program successfully. Make sure that your desired picture in .txt format is located in the same directory as the program files. To run the program, use the following command: ./flood_fill fake_picture.txt
Potential Issues:
-The user is required to provide integer values for the column and row inputs, and single characters representing the desired color.