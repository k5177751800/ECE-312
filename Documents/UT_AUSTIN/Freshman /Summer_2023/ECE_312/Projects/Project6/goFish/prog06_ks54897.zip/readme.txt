Konghwan Shin 
Ks54897 
07/28/2023
Gofish: 
This program allows two players to play the game of Go Fish and records their actions in the "gofish_results.txt" file. The program has no human inputs and simulates on the computer. 

How to Run: 
It is designed to run on Linux and can be executed by following these steps: Upload and unzip the provided zipfile in the desired directory. Open the terminal and navigate to the directory containing the unzipped files. Type "make" and press Enter to compile and link the program. After successful compilation, run the program using the command: ./gofish.

Potential Issues: none 