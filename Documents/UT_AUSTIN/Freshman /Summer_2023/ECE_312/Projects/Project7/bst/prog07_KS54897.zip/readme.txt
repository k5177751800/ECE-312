Konghwan Shin
ECE 312  
KS54897
Aug 2, 2023

BST: 
-A Binary Search Tree (BST) is a data structure that organizes elements in a hierarchical tree-like fashion. It is a special type of binary tree where each node can have at most two children: a left child and a right child. The BST maintains a specific ordering property that makes it efficient for searching, insertion, and deletion operations.
-The goal of this assignment is to implement and test a binary search tree (BST).
How to run:
-unzip the content of the zip file into the Linux directory and then type in the make command. After that, a makefile will compile
-To install the program, unzip the contents into a Linux directory and execute the "make" command. The makefile provided will compile and link the program successfully. Make sure that your desired picture in .txt format is located in the same directory as the program files. To run the program, use the following command: ./Proj7 test.txt
Potential Issues:
None. 


